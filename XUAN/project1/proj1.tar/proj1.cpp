#include<iostream>
#include<string>
#include<sstream>
#include<vector>

using namespace std;//we nneded to have a container to store items and other things 
struct CountEntry {
    string item;
    int count;
};
//simple bubble sort
void customsort(vector<CountEntry>& entries) {
    int n = entries.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (entries[j].count < entries[j + 1].count) {
                swap(entries[j], entries[j + 1]);
            }
        }
    }
}
int main() {
    int lines = 0;//variable for lines
    int words = 0;//var for words
    int chars = 0;//var for chars
    string line;//i decided i need to use a cstring to store items so i need a few diffrent ones
    string word;
    stringstream ss;// this is to parse words in to ss

    //initalize vectors to store items ie chars,identifersm,and numbers
    vector<CountEntry> charcount(128); //I had no idea how i was supposed to until i realized i could use the ascii values to count
    vector<CountEntry> identifiercount;
    vector<CountEntry> numbercount;


	//opens the char vector with empty strings and starts at 0
    for (int i = 0; i < 128; i++) {
        charcount[i].item = string(1, static_cast<char>(i)); // Initialize characters
        charcount[i].count = 0;
    }//read input line by line
    while (getline(cin, line)) {
        lines++;
        ss << line;
		//tokenize the words
        while (ss >> word) {
            words++;
            chars += word.length();
            //char counting
            for (char c : word) {
                int ascii = static_cast<int>(c);
                if (ascii >= 0 && ascii < 128) {
                    charcount[ascii].count++;
                }
            }
            //check to see what type it is in terms of number, chars and identifers
            if (isalpha(word[0])) {
                identifiercount.push_back({word, 1});
            } 
			else if(isdigit(word[0])) {
                numbercount.push_back({word, 1});
            }
        }
        ss.clear();
    } //this is just printing words to the screen
    cout << "Lines: " << lines << endl;
    cout << "Words: " << words << endl;
    cout << "Characters: " << chars << endl;

    //bubble sort
    customsort(charcount);
    customsort(identifiercount);
    customsort(numbercount);

    //after we do our bubble sort we need to sort the items for 
	//each value we need.
	//char print
    cout << "Most used characters:" << endl;
    for (int i = 0; i < min(5, static_cast<int>(charcount.size())); i++) {
        if (charcount[i].count > 0) {
            cout << charcount[i].item << ": " << charcount[i].count << endl;
        }
    }
    //identifyer print 
    cout << "Most used identifiers:" << endl;
    for (int i = 0; i < min(5, static_cast<int>(identifiercount.size())); i++) {
        cout << identifiercount[i].item << ": " << identifiercount[i].count << endl;
    }
    //number print
    cout << "Most used numbers:" << endl;
    for (int i = 0; i < min(5, static_cast<int>(numbercount.size())); i++) {
        cout << numbercount[i].item << ": " << numbercount[i].count << endl;
    }
    return 0;
}
