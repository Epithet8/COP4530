#include <iostream>
#include <string>
#include <algorithm>
#include <map>
#include "hashtable.h"

using namespace std;

void menu()
{
	HashTable<string> ht = HashTable<string>(5);
	char choice;

	choice = ' ';
	while(choice != 'x'){
		cout << "\n\n";
		cout << "l - Load Dictionary From File" << endl;
		cout << "a - Add Word" << endl;
		cout << "r - Remove Word" << endl;
		cout << "c - Clear HashTable" << endl;
		cout << "f - Find Word" << endl;
		cout << "d - Dump HashTable" << endl;
		cout << "s - HashTable Size" << endl;
		cout << "w - Write to File" << endl;
		cout << "x - Exit program" << endl;
		cout << "\nEnter choice : ";
		cin >> choice;
		string filename;
		string word;
		switch(choice){
			case 'l':
				cout << "Enter filename: ";
				cin >> filename;
				ht.load(filename.c_str());
				break;
			case 'a':
				cout << "Enter word: ";
				cin >> word;
				ht.insert(word.c_str());
				break;
			case 'r':
				cout << "Enter word to remove: ";
				cin >> word;
				ht.remove(word.c_str());
				break;
			case 'c':
				ht.clear();
				break;
			case 'f':
				cout << "Enter word to find: ";
				cin >> word;
				cout << word << "exists?: " << ht.contains(word.c_str());
				break;
			case 'd':
				ht.dump();
				break;
			case 's':
				cout << "HashTable size: " << ht.get_size() << endl;
				break;
			case 'w':
				cout << "Enter filename to write: ";
				cin >> filename;
				ht.write_to_file(filename.c_str());
				break;			
			default:
				break;
		}
	}
}

void load_rank(string rank_file, map<string, int>& rank){
  ifstream file;
  file.open(rank_file, ifstream::in);
  if(!file.good()){
    cout << "open rank file failed" << endl;
    return;
  }
  string line;
  string word;
  int val;
  while(getline(file, line)){
    stringstream ss;
    ss.str(line);
    getline(ss, word, ' ');
	ss >> val;
    rank[word] = int(val);   
  }
  file.close();
}

void check(char* argv[]){
	HashTable<string> dict = HashTable<string>();
	dict.load(argv[1]);

	// load rank to map
	map<string, int> rank;
	load_rank("wordrank.txt", rank);

	// load file to spellcheck
	ifstream file;
	file.open(argv[2], ifstream::in);
	if(!file.good()){
		cout << "open unchecked file failed" << endl;
		return;
	}

	// setup output file
	ofstream file2;
	file2.open(argv[3], ofstream::out);
	if(!file2.good()){
		cout << "open checked file failed" << endl;
		return;
	}

	string line, tline;
	string word, tword;
	vector<pair<int, string>> candidates;
	while(getline(file, line)){
		stringstream ss;
		ss.str(line);
		while(getline(ss, word, ' ')){
			tline = line;
			// remove any punctuation at end
			if(ispunct(word[word.length() - 1])){
				word = word.substr(0, word.length() - 1);
			}
			tword = word;
			transform(tword.begin(), tword.end(), tword.begin(), ::tolower); // to lowercase			
			if(!dict.contains(tword) && tword.compare("") != 0){
				tword = word;
				transform(tword.begin(), tword.end(), tword.begin(), ::tolower); // to lowercase
				// sweep alternative letters for each letter to see if match
				for(int i=0; i<tword.length(); i++){
					tword = word;
					for(int j=97; j<123; j++){
						tword[i] = char(j);
						if(dict.contains(tword)){
							if(rank.find(tword) == rank.end()){
								candidates.emplace_back(pair<int, string>(10000, tword));
							}else{
								candidates.emplace_back(pair<int, string>(rank[tword], tword));
							}
						}
					}
				}
				sort(candidates.begin(), candidates.end());
				tword = word;
				transform(tword.begin(), tword.end(), tword.begin(), ::toupper);
				cout << tline.replace(tline.find(word), word.length(), tword) << endl;
				int size = candidates.size();
				if(size > 10){
					size = 10;
				}
				for(int i=0; i<size; i++){
					cout << i << ":" << candidates[i].second << " ";
				}
				cout << endl;
				int n;
				cout << "Choose candidate number or -1: ";
				cin >> n;
				if(n > -1){
					line.replace(line.find(word), word.length(), candidates[n].second);
				}
				candidates.clear();
			}
		}
		file2 << line << endl;
	}
	file.close();
	file2.close();
}

int main(int argc, char* argv[]){
	if(argc == 4){
		check(argv);
	}else{
		menu();
	}
	return 0;
}
