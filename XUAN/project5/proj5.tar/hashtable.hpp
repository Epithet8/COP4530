#ifndef _HASHTABLE_HPP
#define _HASHTABLE_HPP

#include <fstream>
#include <sstream>
#include "hashtable.h"

using namespace std;
using namespace cop4530;

template <typename T>
HashTable<T>::HashTable(size_t size){
  hSize = prime_below(size);
  bucketLL = new vector<list<T>*>();
  for(int i=0; i<hSize; i++){
    bucketLL->push_back(new list<T>());
  }
}

template <typename T>
HashTable<T>::~HashTable(){
  for(int i=0; i<hSize; i++){
    delete bucketLL->at(i);
  }
  delete bucketLL;
  count = 0;
}

template <typename T>
int HashTable<T>::get_size(){
  return hSize;
}

template <typename T>
bool HashTable<T>::contains(const T &x) const{
  list<T>* lst = bucketLL->at(myhash(x));
  for(auto i : *lst){
    if(x.compare(i) == 0){
      return true;
      break;
    }
  }
  return false;
}

template <typename T>
bool HashTable<T>::insert(const T &x){
  if(contains(x)){
    return false;
  }
  if(count == hSize ){
    rehash();
  }
  list<T>* lst = bucketLL->at(myhash(x));
  lst->push_back(x);
  count++;
  return true;
}

template <typename T>
bool HashTable<T>::insert(const T &&x){
  if(contains(x)){
    return false;
  }
  if(count == hSize){
    rehash();
  }
  list<T>* lst = bucketLL->at(myhash(x));
  lst->push_back(move(x));
  count++;
  return true;
}

template <typename T>
bool HashTable<T>::remove(const T &x){
  if(!contains(x)){
    return false;
  }
  list<T>* lst = bucketLL->at(myhash(x));
  lst->remove(x);
  count--;
  return true;
}

template <typename T>
void HashTable<T>::clear(){
  makeEmpty();
}

template <typename T>
bool HashTable<T>::load(const char *filename){
  ifstream file;
  file.open(filename, ifstream::in);
  if(!file.good()){
    cout << "open load file failed" << endl;
    return false;
  }
  string line;
  string word;
  while(getline(file, line)){
    if(line[line.length() - 1] == '\r'){
      line = line.substr(0, line.length() - 1);
    }
    stringstream ss;
    ss.str(line);
    while(getline(ss, word, ' ')){
      insert(word);
    }    
  }
  file.close();
  return true;
}

template <typename T>
void HashTable<T>::dump(){
  list<T>* lst;
  int size = hSize;
  cout << "size: " << hSize << " word count: " << count << endl;
  if(size > 100){
    size = 100;
  }
  for(int i=0; i<size; i++){
    lst = bucketLL->at(i);
    bool flg = false;
    for(auto i : *lst){
      flg = true;
      cout << i << "\t";
    }
    if(flg){
      cout << "[" << i << "]" << endl;
    }
  }
}

template <typename T>
bool HashTable<T>::write_to_file(const char *filename) const{
  ofstream file;
  file.open(filename, ofstream::out);
  if(!file.good()){
    cout << "open output file failed" << endl;
    return false;
  }
  list<T>* lst;
  for(int i=0; i<hSize; i++){
    lst = bucketLL->at(i);
    for(auto i : *lst){
      file << i << endl;
    }
  }
  file.close();
  return true;
}

template <typename T>
void HashTable<T>::makeEmpty(){
  for(int i=0; i<hSize; i++){
    bucketLL->at(i)->clear();
  }
  count = 0;
}

template <typename T>
void HashTable<T>::rehash(){
  if(hSize > 800000){ // prime_below failed if allowed bigger
    return;
  }
  size_t oSize = hSize;
  hSize = prime_below(oSize * 2);
  vector<list<T>*>* obucketLL = bucketLL;
  bucketLL = new vector<list<T>*>();
  for(int i=0; i<hSize; i++){
    bucketLL->push_back(new list<T>());
  }
  list<T>* lst;
  for(int i=0; i<oSize; i++){
    lst = obucketLL->at(i);
    for(auto i : *lst){
      insert(i);
    }
    lst->clear();
    delete lst;
  }
  delete obucketLL;
}

template <typename T>
size_t HashTable<T>::myhash(const T &x) const{
  hash<T> hasher;
  size_t idx = hasher(x) % hSize;
  return idx;
}

// returns largest prime number <= n or zero if input is too large
// This is likely to be more efficient than prime_above(), because
// it only needs a vector of size n
template <typename T>
unsigned long HashTable<T>::prime_below (long n)
{
  if (n > max_prime)
    {
      std::cerr << "** input too large for prime_below()\n";
      return 0;
    }
  if (n == max_prime)
    {
      return max_prime;
    }
  if (n <= 1)
    {
		std::cerr << "** input too small \n";
      return 0;
    }

  // now: 2 <= n < max_prime
  std::vector <long> v (n+1);
  setPrimes(v);
  while (n > 2)
    {
      if (v[n] == 1)
	return n;
      --n;
    }

  return 2;
}

//Sets all prime number indexes to 1. Called by method prime_below(n) 
template <typename T>
void HashTable<T>::setPrimes(std::vector<long>& vprimes)
{
  int i = 0;
  int j = 0;

  vprimes[0] = 0;
  vprimes[1] = 0;
  int n = vprimes.capacity();

  for (i = 2; i < n; ++i)
    vprimes[i] = 1;

  for( i = 2; i*i < n; ++i)
    {
      if (vprimes[i] == 1)
        for(j = i + i ; j < n; j += i)
          vprimes[j] = 0;
    }
}
#endif
