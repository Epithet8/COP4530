#ifndef _BST_H
#define _BST_H

#include <iostream>

namespace cop4530{
    template <typename T>
    class BSTNode{
        public:
            T data;
            int visits;
            BSTNode<T>* left;
            BSTNode<T>* right;
    };

    template <typename T>
    class BST{
        private:
            int threshold_value;
            BSTNode<T>* root;

            void printInOrder(BSTNode<T>* t) const;
            void printLevelOrder(BSTNode<T>* t, int lev) const;
            int numOfNodes(BSTNode<T>* t) const;
            int height(BSTNode<T>* t) const;
            void makeEmpty(BSTNode<T>* &t);
            BSTNode<T>* insert(const T& v, BSTNode<T>* &t);
            BSTNode<T>* insert(T&& v, BSTNode<T>* &t);
            void remove(const T& v, BSTNode<T>* &t, BSTNode<T>* &pred);
            bool contains(const T& v, BSTNode<T>* &t);
            BSTNode<T>* clone(BSTNode<T>* t) const;

        public:
            BST(int th=1);
            BST(const std::string input, int th=1);

            BST(const BST& rhs);
            BST(BST&& rhs);
            ~BST();
            const BST& operator=(const BST& rhs);
            const BST& operator=(BST&& rhs);

            void buildFromInputString(const std::string input);
            bool empty();

            void printInOrder() const;
            void printLevelOrder() const;
            int numOfNodes() const;
            int height() const;
            void makeEmpty();
            void insert(const T& v);
            void insert(T&& v);
            void remove(const T& v);
            bool contains(const T& v);
    };
}

#include "BST.hpp"

#endif