#ifndef _Stack_hpp
#define _Stack_hpp

#include <iostream>
#include <string>
#include <stdexcept>
#include <vector>

template <typename T>
Stack<T>::Stack(){
    m_stack = new std::vector<T>;
}

template <typename T>
Stack<T>::~Stack(){ // destructor
    delete m_stack;
}

template <typename T>
Stack<T>::Stack(const Stack<T> &rhs){ // copy constructor
    m_stack = new std::vector<T>;
    for(int i=0; i<rhs.m_stack->size(); i++){
        m_stack->push_back(rhs.m_stack->at(i));
    }
}

template <typename T>
Stack<T>::Stack(Stack<T> &&rhs){ // move constructor
    m_stack = rhs.m_stack;
    rhs.m_stack = nullptr;
}

template <typename T>
Stack<T>& Stack<T>::operator=(const Stack<T> &rhs){ // copy assignment
    if(this != &rhs){
        for(int i=0; i<rhs.m_stack->size(); i++){
            m_stack->push_back(rhs.m_stack->at(i));
        }
    }
    return *this;
}

template <typename T>
Stack<T>& Stack<T>::operator=(Stack<T> &&rhs){ // move assignment
    if(this != &rhs){
        delete m_stack;
        m_stack = rhs.m_stack;
        rhs.m_stack = nullptr;
    }
    return *this;
}

template <typename T>
bool Stack<T>::empty() const{
    if(m_stack->size() == 0){
        return true;
    }
    return false;
}
    
template <typename T>
T& Stack<T>::top(){
    if(m_stack->size() > 0){
        return m_stack->back();
    }else{
        throw std::invalid_argument("Stack empty");
    }
}
  
template <typename T>
const T& Stack<T>::top() const{
    if(m_stack->size() > 0){
        return m_stack->back();
    }else{
        throw std::invalid_argument("Stack empty");
    }
}
    
template <typename T>
void Stack<T>::pop(){
    m_stack->pop_back();
}
    
template <typename T>
void Stack<T>::push(const T &val){
    m_stack->push_back(val);
}
    
template <typename T>
void Stack<T>::push(T &&val){
    m_stack->push_back(std::move(val));
}
    
template <typename T>
int Stack<T>::size(){
    return m_stack->size();
}

template <typename T>
void Stack<T>::print(std::ostream& os, char ofc) const{
    for(int i=0; i<m_stack->size(); i++){
        os << m_stack->at(i);
        if(i < m_stack->size() -1){
            os << ofc;
        } 
    }
}

#endif