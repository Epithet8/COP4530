#include <iostream>
#include "Stack.h"


//questions do we need to show all possible paths? or a complete path
using namespace std;
using namespace cop4530;

int main() {
    Stack<pair<int, int>> stack; //gets pairs for path to follow 
    pair<int, int> coord;// holds row and collem ability to also add cordinates
    int nrows;//number of rows
    int ncols;//number of collums
    int sr;//starting row
    int sc;//starting collums
    int er;//ending row
    int ec;//ending collum
    int cr;//current row
    int cc;//current collum

    cin >> nrows;//to get rows 
    cin >> ncols;//to get collums 
    int cells[nrows][ncols];//2d array to describes cells
    int visited[nrows][ncols];//created a visited 2d array like a flag
    for(int i=0; i<nrows; i++){             //read by rows
        for(int j=0; j<ncols; j++){			//reading through collums
            cin >> cells[i][j];				//cin preforms the read and it goes into cells i j
            visited[i][j] = 0;				//set visited flag as not visted
        }
    }
				//reading in of starting row collum and ending for both
    cin >> sr;
    cin >> sc;
    cin >> er;
    cin >> ec;
			
    cr = sr;		//set staring positions
    cc = sc;
    bool moved = true;	
    coord.first = cr; //first cord to be pushed on the stack sets cord to current and mark as visited
    coord.second = cc;
    stack.push(coord);
    visited[cr][cc] = 1;
    while(moved && !(cr == er && cc == ec)){      //while we have moved or if we have not reached the end
        //cout << cr << " : " << cc << endl;
        moved = false;
        if((cells[cr][cc] & 0x1) == 0 && cr - 1 > -1 && visited[cr - 1][cc] == 0){//checks to the cell to the North to see if the 1s bit is 0 or not also checks viisted cells however before we check to see if we can move
            cr--;
            //cout << "North" << endl;
            moved = true;
        }else if((cells[cr][cc] & 0x2) == 0 && cc + 1 < ncols && visited[cr][cc + 1] == 0){//if 2s bit is not on i can go east then dont go outside the boundaries 
            cc++;//increment collum and set move to true
            //cout << "East" << endl;
            moved = true;
        }else if((cells[cr][cc] & 0x4) == 0 && cr + 1 < nrows && visited[cr + 1][cc] == 0){
            cr++;
            //cout << "South" << endl;
            moved = true;
        }else if((cells[cr][cc] & 0x8) == 0 && cc - 1 > -1 < ncols && visited[cr][cc - 1] == 0){
            cc--;
            //cout << "West" << endl;
            moved = true;
        }
        if(moved){				//if moved check new position to push to stack then mark visited
            coord.first = cr;
            coord.second = cc;
            stack.push(coord);
            visited[cr][cc] = 1;
        }else if(!(cr == er && cc == ec) && !(cr == sr && cc == sc)){//if we didnt move or deadend we pop the curentpos off the stack and use the next item in the stack as the new current and mark as moved
            // go back a step and try again
            stack.pop();
            coord = stack.top();
            cr = coord.first;
            cc = coord.second;
            moved = true;
        }
    }
    if(cr == er && cc == ec){//check to see if we made it to the end 
        cout << "Maze solution:" << endl;
        string str; //hold the route for the maze
        string spair;// converting cords into a print
        int size = stack.size();
        for(int i=size; i>0; i--){//pop a cord of the top of the stack and print the first and second.
            coord = stack.top();
            spair = "(" + to_string(coord.first) + "," + to_string(coord.second) + ")";
            stack.pop();
            if(i > 1){	//if we print the top of the stack
                str = "->" + spair + str;
            }else{
                str = spair + str;
            }
        }
        int cnt = 0;
        for(int i=0; i<str.length(); i++){
            if(str[i] == '('){
                cnt++;
                if(cnt == 11){
                    cout << endl;
                    cnt = 0;
                }
            }
            cout << str[i];
        }
        cout << endl;
    }else{//deadend check
        cout << "No path to food" << endl;
    }
}