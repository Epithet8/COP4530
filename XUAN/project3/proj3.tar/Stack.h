#ifndef _Stack_h
#define _Stack_h

#include <iostream>
#include <string>
#include <stdexcept>
#include <vector>

namespace cop4530{

    template <typename T>
    class Stack{
        private:
            std::vector<T>* m_stack;

        public:
            Stack();

            ~Stack();
            Stack(const Stack &rhs);
            Stack(Stack &&rhs);
            Stack& operator=(const Stack &rhs);
            Stack& operator=(Stack &&rhs);

            bool empty() const;
            T& top();
            const T& top() const;
            void pop();
            void push(const T &val);
            void push(T &&val);
            int size();
            void print(std::ostream& os, char ofc = ' ') const;
    };

#include "Stack.hpp"
}
#endif